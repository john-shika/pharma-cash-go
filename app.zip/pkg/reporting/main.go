package main

import (
	"fmt"
	"nokowebapi/nokocore"
)

func main() {
	n := 12
	nokocore.KeepVoid(n)
	fmt.Println(n)
}
